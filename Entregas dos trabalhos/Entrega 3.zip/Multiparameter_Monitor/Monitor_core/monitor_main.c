/*
 * monitor_main.c
 *
 *  Created on: Oct 30, 2023
 *      Author: lucas
 */



void setup();

void loop();



/*código aula 7/11*/

/*switch(gpio_PIN)
 *
 * case (USR SWT PIN)
 *
 * Desliga interrupção IRQ()
 *
 * liga timer
 *
 *
 *chama callback do app
 * HAL_(Nome do que eu quero)_(Função)(variável)
 *
 *
 *
 * void halTim
 *
 * configurar um timer led desligado aperta botão liga o timer
 * ligar o led e gera interrupções que liga e desliga o led pra kraio
 * fazer funções do calback
 *
 *
 * */



